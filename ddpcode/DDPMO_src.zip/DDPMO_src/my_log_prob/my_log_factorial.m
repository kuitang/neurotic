
function result = my_log_factorial(n)



vec = [1:n];

logvec = log(vec);

result = sum(logvec);