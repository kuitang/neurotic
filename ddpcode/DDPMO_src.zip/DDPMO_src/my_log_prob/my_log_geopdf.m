
function prob = my_log_geopdf(x, p)


prob = x*log(1-p) + log(p);