
function result = my_log_gamma(n)

% computes log of gamma function





array = 1:(n-1);

result = sum(log(array));